# Uncertainty study: coverage and blocker report (2026-10-16T07:50:06+00:00)

| regime | expected | maps OK | scored |
|---|---|---|---|
| A | 1996 | 1970 | 1970 |
| B2 | 178 | 158 | 158 |
| B3 | 178 | 158 | 158 |

Missing explanation units by regime/explainer: A/kernelshap 23, A/shap_permutation 3, B2/kernelshap 10, B2/shap_permutation 10, B3/kernelshap 10, B3/shap_permutation 10

## Metric MC / parameter sensitivity / split screen
- MC/F outputs not OK: 0 of 148
- Split screen: OK (76/76 valid rows)
- Finite-sample resampling (D) is computed inside uf.analyze (RNG 20261011) at the final stage; no separate task.

## Execution provenance audit
- Completed units not computed on cuda: 0; completed units with CPU OOM fallback calls: 0
- CWRU IG/EG/DeepSHAP regime A: {'expected': 84, 'map_ok': 84, 'device_cuda': 84, 'with_cpu_fallback': 0}
- FD001 TCN s11 PermutationSHAP saved samples: {'saved': 205, 'valid': 205, 'invalid': [], 'stray_tmp_files': []}

## Running
- gpu: {'task': 'explain:A/CWRU_12k/GRU/s33/kernelshap', 'attempt': 1, 'pid': 218573, 'elapsed_min': 23.7, 'log': '/home/user1/experiments_true-x/r2_shap_hpc_bundle/uncertainty_final/orchestrator/logs/explain__A__CWRU_12k__GRU__s33__kernelshap__try1.log', 'samples': '16/30', 'new_this_run': 16, 'idle_min': 0.0, 'stall_limit_min': 30.0}
- cpu: None

## Blockers
- none

## Final stage
- not ready because: ['66 explanation units not complete']
- marker: None
- pack present: final_pack/uncertainty_final_results_20261012T012441.tar.gz valid=False

## Remaining explanation units and ETA (single GPU lane, explanations only: 69.8 h)
ETA uses this study's observed per-sample wall time where available, else the production per-sample time (not a guarantee).

| unit | saved samples | per-sample s (source) | est. h |
|---|---|---|---|
| A/CWRU_12k/GRU/s33/kernelshap | 10/30 | 88.0 (observed) | 0.52 |
| A/CWRU_12k/GRU/s55/kernelshap | 0/30 | 88.0 (observed) | 0.77 |
| A/CWRU_12k/INCEPTIONTIME/s11/kernelshap | 0/30 | 204.94 (production) | 1.74 |
| A/CWRU_12k/INCEPTIONTIME/s33/kernelshap | 0/30 | 204.94 (production) | 1.74 |
| A/CWRU_12k/INCEPTIONTIME/s55/kernelshap | 0/30 | 204.94 (production) | 1.74 |
| A/CWRU_12k/LOGISTIC_CLASSIFIER/s11/kernelshap | 0/30 | 10.19 (production) | 0.12 |
| A/CWRU_12k/LOGISTIC_CLASSIFIER/s33/kernelshap | 0/30 | 10.19 (production) | 0.12 |
| A/CWRU_12k/LOGISTIC_CLASSIFIER/s55/kernelshap | 0/30 | 10.19 (production) | 0.12 |
| A/CWRU_12k/LSTM/s11/kernelshap | 0/30 | 152.85 (production) | 1.31 |
| A/CWRU_12k/LSTM/s33/kernelshap | 0/30 | 152.85 (production) | 1.31 |
| A/CWRU_12k/LSTM/s55/kernelshap | 0/30 | 152.85 (production) | 1.31 |
| A/CWRU_12k/RESNET/s11/kernelshap | 0/30 | 78.68 (production) | 0.69 |
| A/CWRU_12k/RESNET/s33/kernelshap | 0/30 | 78.68 (production) | 0.69 |
| A/CWRU_12k/RESNET/s55/kernelshap | 0/30 | 78.68 (production) | 0.69 |
| A/CWRU_12k/TIME_CNN/s11/kernelshap | 0/30 | 10.64 (production) | 0.12 |
| A/CWRU_12k/TIME_CNN/s33/kernelshap | 0/30 | 10.64 (production) | 0.12 |
| A/CWRU_12k/TIME_CNN/s55/kernelshap | 0/30 | 10.64 (production) | 0.12 |
| A/CWRU_12k/TST/s11/kernelshap | 0/30 | 40.04 (production) | 0.37 |
| A/CWRU_12k/TST/s33/kernelshap | 0/30 | 40.04 (production) | 0.37 |
| A/CWRU_12k/TST/s55/kernelshap | 0/30 | 40.04 (production) | 0.37 |
| B2/CWRU_12k/ENCODER/prod/kernelshap | 0/30 | 51.348 (observed) | 0.46 |
| B2/CWRU_12k/ENCODER/prod/shap_permutation | 0/30 | 40.0 (observed) | 0.37 |
| B2/CWRU_12k/FCN/prod/kernelshap | 0/30 | 43.0 (observed) | 0.39 |
| B2/CWRU_12k/FCN/prod/shap_permutation | 0/30 | 33.137 (observed) | 0.31 |
| B2/CWRU_12k/GRU/prod/kernelshap | 0/30 | 88.0 (observed) | 0.77 |
| B2/CWRU_12k/GRU/prod/shap_permutation | 0/30 | 69.0 (observed) | 0.61 |
| B2/CWRU_12k/INCEPTIONTIME/prod/kernelshap | 0/30 | 204.94 (production) | 1.74 |
| B2/CWRU_12k/INCEPTIONTIME/prod/shap_permutation | 0/30 | 162.3 (observed) | 1.39 |
| B2/CWRU_12k/LOGISTIC_CLASSIFIER/prod/kernelshap | 0/30 | 10.19 (production) | 0.12 |
| B2/CWRU_12k/LOGISTIC_CLASSIFIER/prod/shap_permutation | 0/30 | 7.0 (observed) | 0.09 |
| B2/CWRU_12k/LSTM/prod/kernelshap | 0/30 | 152.85 (production) | 1.31 |
| B2/CWRU_12k/LSTM/prod/shap_permutation | 0/30 | 123.0 (observed) | 1.06 |
| B2/CWRU_12k/RESNET/prod/kernelshap | 0/30 | 78.68 (production) | 0.69 |
| B2/CWRU_12k/RESNET/prod/shap_permutation | 0/30 | 62.0 (observed) | 0.55 |
| B2/CWRU_12k/TIME_CNN/prod/kernelshap | 0/30 | 10.64 (production) | 0.12 |
| B2/CWRU_12k/TIME_CNN/prod/shap_permutation | 0/30 | 7.362 (observed) | 0.09 |
| B2/CWRU_12k/TST/prod/kernelshap | 0/30 | 40.04 (production) | 0.37 |
| B2/CWRU_12k/TST/prod/shap_permutation | 0/30 | 30.0 (observed) | 0.28 |
| B3/CWRU_12k/ENCODER/prod/kernelshap | 0/30 | 51.348 (observed) | 0.46 |
| B3/CWRU_12k/ENCODER/prod/shap_permutation | 0/30 | 40.0 (observed) | 0.37 |
| B3/CWRU_12k/FCN/prod/kernelshap | 0/30 | 43.0 (observed) | 0.39 |
| B3/CWRU_12k/FCN/prod/shap_permutation | 0/30 | 33.137 (observed) | 0.31 |
| B3/CWRU_12k/GRU/prod/kernelshap | 0/30 | 88.0 (observed) | 0.77 |
| B3/CWRU_12k/GRU/prod/shap_permutation | 0/30 | 69.0 (observed) | 0.61 |
| B3/CWRU_12k/INCEPTIONTIME/prod/kernelshap | 0/30 | 204.94 (production) | 1.74 |
| B3/CWRU_12k/INCEPTIONTIME/prod/shap_permutation | 0/30 | 162.3 (observed) | 1.39 |
| B3/CWRU_12k/LOGISTIC_CLASSIFIER/prod/kernelshap | 0/30 | 10.19 (production) | 0.12 |
| B3/CWRU_12k/LOGISTIC_CLASSIFIER/prod/shap_permutation | 0/30 | 7.0 (observed) | 0.09 |
| B3/CWRU_12k/LSTM/prod/kernelshap | 0/30 | 152.85 (production) | 1.31 |
| B3/CWRU_12k/LSTM/prod/shap_permutation | 0/30 | 123.0 (observed) | 1.06 |
| B3/CWRU_12k/RESNET/prod/kernelshap | 0/30 | 78.68 (production) | 0.69 |
| B3/CWRU_12k/RESNET/prod/shap_permutation | 0/30 | 62.0 (observed) | 0.55 |
| B3/CWRU_12k/TIME_CNN/prod/kernelshap | 0/30 | 10.64 (production) | 0.12 |
| B3/CWRU_12k/TIME_CNN/prod/shap_permutation | 0/30 | 7.362 (observed) | 0.09 |
| B3/CWRU_12k/TST/prod/kernelshap | 0/30 | 40.04 (production) | 0.37 |
| B3/CWRU_12k/TST/prod/shap_permutation | 0/30 | 30.0 (observed) | 0.28 |
| A/FD001/TCN_REGRESSOR/s11/kernelshap (TCN) | 0/497 | 0.707 (production) | 0.13 |
| A/FD001/TCN_REGRESSOR/s11/shap_permutation (TCN) | 205/497 | 52.431 (observed) | 4.29 |
| A/FD001/TCN_REGRESSOR/s33/kernelshap (TCN) | 0/497 | 0.707 (production) | 0.13 |
| A/FD001/TCN_REGRESSOR/s33/shap_permutation (TCN) | 0/497 | 52.431 (observed) | 7.27 |
| A/FD001/TCN_REGRESSOR/s55/kernelshap (TCN) | 0/497 | 0.707 (production) | 0.13 |
| A/FD001/TCN_REGRESSOR/s55/shap_permutation (TCN) | 0/497 | 52.431 (observed) | 7.27 |
| B2/FD001/TCN_REGRESSOR/prod/kernelshap (TCN) | 0/497 | 0.707 (production) | 0.13 |
| B2/FD001/TCN_REGRESSOR/prod/shap_permutation (TCN) | 0/497 | 52.431 (observed) | 7.27 |
| B3/FD001/TCN_REGRESSOR/prod/kernelshap (TCN) | 0/497 | 0.707 (production) | 0.13 |
| B3/FD001/TCN_REGRESSOR/prod/shap_permutation (TCN) | 0/497 | 52.431 (observed) | 7.27 |
